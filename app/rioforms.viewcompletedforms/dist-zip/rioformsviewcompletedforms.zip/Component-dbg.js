sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("rioforms.viewcompletedforms.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);